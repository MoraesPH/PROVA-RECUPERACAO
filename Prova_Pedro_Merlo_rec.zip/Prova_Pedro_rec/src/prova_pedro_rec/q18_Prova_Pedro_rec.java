
package prova_pedro_rec;

import java.io.DataInputStream;
import java.io.IOException;


public class q18_Prova_Pedro_rec {
    
    public static void main(String[] args) throws IOException {
        DataInputStream dado;
        String aux;
        int horas_trabalhadas;
        float salario_hr = 0, salario_bruto = 0, salario_liquido = 0, inss = 0, ir = 0,sindicato = 0, desconto = 0;
        
        System.out.println("Digite quanto voce ganha por hora: ");
        dado = new DataInputStream(System.in);
        aux = dado.readLine();
        salario_hr = Float.parseFloat(aux);
        
        System.out.println("Quantas horas voce trabalhou no mes: ");
        dado = new DataInputStream(System.in);
        aux = dado.readLine();
        horas_trabalhadas = Integer.parseInt(aux);
        
        salario_bruto = salario_hr * horas_trabalhadas;
        inss = (float) (salario_bruto - (salario_bruto * 0.08));
        desconto = (float) (desconto + (salario_bruto * 0.08));
        ir = (float) (inss - (salario_bruto * 0.11));
        desconto = (float) (desconto + (salario_bruto * 0.11));
        sindicato = (float) (ir - (salario_bruto * 0.05));
        desconto = (float) (desconto + (salario_bruto * 0.05));
        
        
        
        
        salario_liquido = salario_bruto - desconto;
        
        System.out.println("O seu salario bruto e de: R$"+salario_bruto);
        System.out.println("O seu salario descontado o INSS e de: R$"+inss);
        System.out.println("O seu salario descontado o Inposto de renda e de: R$"+ir);
        System.out.println("O seu salario descontado o sindicato e de: R$"+sindicato);
        System.out.println("O seu salario liquido e de: R$"+salario_liquido);
        
        
        
    }
}
