
package prova_pedro_rec;

import java.io.DataInputStream;
import java.io.IOException;

public class q2_Prova_Pedro_rec {

    
    public static void main(String[] args) throws IOException {
        DataInputStream dado;
        String aux;
        int opc, quantidade_exp = 0, quantidade_cap = 0, quantidade_lei = 0, quantidade = 0;
        float preco,preco_exp = 0,preco_cap = 0, preco_lei = 0, soma = 0;
        
        while(true){
            System.out.println("Cafeteira");
            System.out.println("1-Cafe expresso");
            System.out.println("2-Cafe capuccino");
            System.out.println("3-Leite com cafe");
            System.out.println("4-Totalizar vendas");
            dado = new DataInputStream(System.in);
            aux = dado.readLine();
            opc = Integer.parseInt(aux);
        
            if(opc == 1){
                quantidade_exp ++;
                preco = (float) 0.75;
                preco_exp = preco_exp + preco;  
            }else if(opc == 2){
                quantidade_cap ++;
                preco = (float) 1.00;
                preco_cap = preco_cap + preco;
            }else if(opc == 3){
                quantidade_lei ++;
                preco = (float) 1.25;
                preco_lei = preco_lei + preco;
            }else if(opc == 4){
                soma = preco_exp + preco_cap + preco_lei;
                quantidade = quantidade_exp + quantidade_cap + quantidade_lei;
                System.out.println("A quantidade de cafe expresso vendida foi de: "+quantidade_exp+"| O valor total em Reais foi de: R$"+preco_exp);
                System.out.println("A quantidade de cafe capuccino vendida foi de: "+quantidade_cap+"| O valor total em Reais foi de: R$"+preco_cap);
                System.out.println("A quantidade de cafe expresso vendida foi de: "+quantidade_lei+"| O valor total em Reais foi de: R$"+preco_lei);
                System.out.println("A quantidade de cafes vendidos no total foi de: "+quantidade+"| O valor total em Reais foi de: R$"+soma);
                break;
            }    
        }
        
    }
    
}
