
package prova_pedro_rec;

import java.io.IOException;
import javax.swing.JOptionPane;


public class q3_Prova_Pedro_rec {
    
    public static void main(String[] args) throws IOException {
        int n1, ant, suc;
        String aux;
        
        aux = JOptionPane.showInputDialog("Digite um numero: ");
        n1 = Integer.parseInt(aux);
        
        ant = n1 - 1;
        suc = n1 + 1;
        
        JOptionPane.showMessageDialog(null, "O antecessor de "+n1+" = "+ant);
        JOptionPane.showMessageDialog(null, "O antecessor de "+n1+" = "+suc);
    }
    
}
