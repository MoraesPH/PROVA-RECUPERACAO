
package prova_pedro_rec;

import java.io.DataInputStream;
import java.io.IOException;


public class q4_Prova_Pedro_rec {
    
    public static void main(String[] args) throws IOException {
        DataInputStream dado;
        String aux;
        int cod_usuario, cod_armz = 1234, senha, senha_armz = 9999;
        
        while(true){
            System.out.println("Digite o codigo de usuario");
            dado = new DataInputStream(System.in);
            aux = dado.readLine();
            cod_usuario = Integer.parseInt(aux);
            
            if(cod_usuario == cod_armz){
                break;
            }
        }
        while(true){
            System.out.println("Digite a senha de usuario: ");
            dado = new DataInputStream(System.in);
            aux = dado.readLine();
            senha = Integer.parseInt(aux);
            
            if(senha == senha_armz){
                System.out.println("Acesso Permitido");
                    break;
            } 
        }
        
    }
}
