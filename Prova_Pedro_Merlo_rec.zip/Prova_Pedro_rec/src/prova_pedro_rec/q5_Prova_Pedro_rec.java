
package prova_pedro_rec;

import java.io.DataInputStream;
import java.io.IOException;


public class q5_Prova_Pedro_rec {
    
    public static void main(String[] args) throws IOException {
         DataInputStream dado;
         String aux, resp = "s";
         int n, soma = 0, quantidade = 0;
         float media;
         
         while(true){
            System.out.println("Digite um numero: ");
            dado = new DataInputStream(System.in);
            aux = dado.readLine();
            n = Integer.parseInt(aux);
            quantidade ++;
            soma = soma + n;
             
             
             
            System.out.println("Deseja escrever outro numero (s/n)");
            resp = dado.readLine();
            
            if(resp.equals("n")){
                break;
            }
         }
        media = soma / quantidade;
         
        System.out.println("A quantidade de valores digitados foi de: "+quantidade);
        System.out.println("A soma dos valores foi de: "+soma);
        System.out.println("A media dos valores foi de: "+media); 
             
             
         
     }
}
