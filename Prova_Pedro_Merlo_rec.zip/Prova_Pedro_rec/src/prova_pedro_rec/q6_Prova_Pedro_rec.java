
package prova_pedro_rec;

import java.io.DataInputStream;
import java.io.IOException;


public class q6_Prova_Pedro_rec {
    
    public static void main(String[] args) throws IOException {
        DataInputStream dado;
        String player1, player2, nome_filme, palpite;
        String dicas[] = new String[5];
        
        System.out.println("Jogador 1, digite seu nome: ");
        dado = new DataInputStream(System.in);
        player1 = dado.readLine();
        
        System.out.println(player1+" - Digite o nome do filme: ");
        dado = new DataInputStream(System.in);
        nome_filme = dado.readLine();
        
        System.out.println("Digite 5 dicas para o jogador 2");
        for (int i = 0; i < dicas.length; i++) {
            System.out.println((i + 1)+" dica: ");
            dicas[i] = dado.readLine();
        }
        
        System.out.println("Jogador 2, digite seu nome: ");
        dado = new DataInputStream(System.in);
        player2 = dado.readLine();
        
        for (int i = 0; i < dicas.length; i++) {
            System.out.println(player2+", a pista "+(i+1)+" e:"+dicas[i]);
            System.out.println(player2+", Qual o nome do filme");
            palpite = dado.readLine();
            
            if(palpite.equals(nome_filme)){
               System.out.println("Parabens, voce acertou");
               break;
            }else{
                System.out.println("errou"); 
            }   
        }
        
    }
}
